<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PropertyDetail extends Model
{
    use HasFactory;
    protected $fillable = [
        'project_id',
        'title',
        'image',
        'added_by',
        'updated_by',
    ];

    // Relationships
    public function project()
    {
        return $this->belongsTo(Project::class);
    }
}
