<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
    <p>Your OTP code is: <strong>{{ $otp_code }}</strong></p>
</body>
</html>
