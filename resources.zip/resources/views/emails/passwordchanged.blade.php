<!DOCTYPE html>
<html>
<head>
    <title>Password Changed</title>
</head>
<body>
    <h1>Hello, {{ $user->name }}</h1>
    <p>Your password has been successfully changed.</p>
    <p>If you did not request this change, please contact support immediately.</p>
</body>
</html>
